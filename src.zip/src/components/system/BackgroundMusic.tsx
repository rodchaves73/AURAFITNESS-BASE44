"use client";

import { useEffect, useRef, useState } from 'react';

/**
 * @fileOverview Sistema de Áudio Ambiente do Aura System.
 * Sincronizado com o arquivo local fornecido pelo Caçador.
 * O botão foi removido para purificar o HUD; o áudio inicia automaticamente.
 */
export function BackgroundMusic() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Sincronizando com o rastro sonoro local: ambient music.mp3
      const audioSource = '/ambient music.mp3';
      
      if (!audioRef.current) {
        audioRef.current = new Audio(audioSource);
        audioRef.current.loop = true;
        audioRef.current.volume = 0.3;
      }
      
      const startAudio = () => {
        if (audioRef.current && !isInitialized) {
          audioRef.current.play()
            .then(() => {
              setIsInitialized(true);
            })
            .catch(err => {
              // Silêncio tático: o Nexus aguarda interação do Caçador para desbloquear o fluxo
              console.warn("Nexus: Autoplay aguardando interação do Caçador.");
            });
        }
      };

      // Tenta iniciar imediatamente após o carregamento da Aura
      // Se o Caçador já interagiu com o sistema (ex: botão Intro), o áudio fluirá
      startAudio();

      // Protocolo de contingência: ativa no primeiro toque global se o autoplay falhar
      const handleGlobalInteraction = () => {
        startAudio();
      };

      window.addEventListener('click', handleGlobalInteraction, { once: true });
      window.addEventListener('touchstart', handleGlobalInteraction, { once: true });
      
      return () => {
        window.removeEventListener('click', handleGlobalInteraction);
        window.removeEventListener('touchstart', handleGlobalInteraction);
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.src = "";
          audioRef.current = null;
        }
      };
    }
  }, [isInitialized]);

  return null; // Interface purificada conforme diretriz absoluta: o botão foi removido.
}
